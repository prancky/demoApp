import React from 'react';
import { Platform } from 'react-native';
import {
  createStackNavigator,
  createBottomTabNavigator,
} from 'react-navigation';

import Resturant from './../screens/resturant';

const MainNavigator = createStackNavigator(
  {
    Main: {
      screen: Resturant,
    },
  },
  {
    navigationOptions: () => ({
      header: null,
    }),
  }
);

export default createStackNavigator({
  MainNavigator
});
