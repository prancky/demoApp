const tintColor = '#2f95dc';

export default {
  tintColor,
  tabIconDefault: '#ccc',
  tabIconSelected: tintColor,
  tabBar: '#fefefe',
  errorBackground: 'red',
  errorText: '#fff',
  warningBackground: '#EAEB5E',
  warningText: '#666804',
  noticeBackground: tintColor,
  noticeText: '#fff',
  green : '#44D200',
  yellow : '#FFD54F',
  gray : '#B0BEC5',
  darkGray : '#3C344B',
  blue :'#00A6FF'
};
