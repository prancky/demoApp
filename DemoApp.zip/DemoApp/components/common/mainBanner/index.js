import React, { Component } from "react";
import { View, Text, Image, StyleSheet } from "react-native";
import sample from "./../../../assets/images/josephsnyc_homepage3new1140x587.jpg";

class MainBanner extends Component {
  render() {
    let imgHeight = { height: this.props.height };
    return (
      <View style={styles.box}>
        <Image
          style={[styles.image, imgHeight]}
          source={require("./../../../assets/images/josephsnyc_homepage3new1140x587.jpg")}
        />
        <View style={[styles.content, imgHeight]}>{this.props.children}</View>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  box: {
    flex: 1,
    position: "relative"
  },
  image: {
    width: "100%",
    height: 200
  },
  content: {
    position: "absolute",
    width: "100%",
    backgroundColor: "rgba(0, 0, 0 ,0.4)"
  }
});
MainBanner.defaultProps = {
  children: null
};
export { MainBanner };
