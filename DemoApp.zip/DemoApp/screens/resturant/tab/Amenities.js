import React from "react";
import { View, Text, StyleSheet, Dimensions } from "react-native";
import Colors from "./../../../constants/Colors";
import { Ionicons } from "@expo/vector-icons";
var { width } = Dimensions.get("window");

const Amenities = () => {
  return (
    <View style={styles.box}>
      <Text style={styles.header}>Amenities</Text>
      <View style={styles.items}>
        <View style={styles.item}>
          <Ionicons
            name="md-checkmark"
            size={22}
            color={Colors.darkGray}
            style={{ width: 20 }}
          />
          <Text style={styles.item_text}>Buffet</Text>
        </View>
        <View style={styles.item}>
          <Ionicons
            name="md-checkmark"
            size={22}
            color={Colors.darkGray}
            style={{ width: 20 }}
          />
          <Text style={styles.item_text}>Takeaway</Text>
        </View>
        <View style={styles.item}>
          <Ionicons
            name="md-checkmark"
            size={22}
            color={Colors.darkGray}
            style={{ width: 20 }}
          />
          <Text style={styles.item_text}>Drive Through</Text>
        </View>
        <View style={styles.item}>
          <Ionicons
            name="md-checkmark"
            size={22}
            color={Colors.darkGray}
            style={{ width: 20 }}
          />
          <Text style={styles.item_text}>Card Payments</Text>
        </View>
        <View style={styles.item}>
          <Ionicons
            name="md-checkmark"
            size={22}
            color={Colors.darkGray}
            style={{ width: 20 }}
          />
          <Text style={styles.item_text}>Wifi</Text>
        </View>
        <View style={styles.item}>
          <Ionicons
            name="md-checkmark"
            size={22}
            color={Colors.darkGray}
            style={{ width: 20 }}
          />
          <Text style={styles.item_text}>Outdoor Seating</Text>
        </View>
        <View style={styles.item}>
          <Ionicons
            name="md-checkmark"
            size={22}
            color={Colors.darkGray}
            style={{ width: 20 }}
          />
          <Text style={styles.item_text}>Alcohol</Text>
        </View>
        <View style={styles.item}>
          <Ionicons
            name="md-checkmark"
            size={22}
            color={Colors.darkGray}
            style={{ width: 20 }}
          />
          <Text style={styles.item_text}>Parking</Text>
        </View>
      </View>
    </View>
  );
};
const styles = StyleSheet.create({
  box: {
    paddingLeft: 10,
    paddingRight: 10,
    paddingTop: 15,
    paddingBottom: 15
  },
  header: {
    color: Colors.darkGray, 
    fontSize: 17
  },
  items: {
    flex: 1,
    flexDirection: "row",
    marginTop: 15,
    flexWrap: "wrap"
  },
  item: {
    // flex: 0.5,
    flexDirection: "row",
    width: width / 2 - 20
  },
  item_text: {
    marginTop: 4,
    marginLeft: 10,
    fontSize: 14
  }
});
export default Amenities;
