import React from "react";
import { View, StyleSheet, Text } from "react-native";
import { Ionicons } from "@expo/vector-icons";
import Colors from "./../../../constants/Colors";

const Highlights = () => {
  return (
    <View style={styles.box}>
      <Text style={styles.header}>Highlights</Text>
      <View style={styles.list_item}>
        <View style={styles.list}>
          <Ionicons name="ios-restaurant" size={22} color={Colors.darkGray} style={{width:20}}/>
          <View style={styles.items}>
            <View style={styles.item}>
              <View style={styles.dot} />
              <Text> Mexican</Text>
            </View>
            <View style={styles.item}>
              <View style={styles.dot} />
              <Text> English</Text>
            </View>
            <View style={styles.item}>
              <View style={styles.dot} />
              <Text> Chinease</Text>
            </View>
          </View>
        </View>
        <View style={styles.list}>
          <Ionicons name="ios-pizza" size={22} color={Colors.darkGray} style={{width:20}}/>
          <View style={styles.items}>
            <View style={styles.item}>
              <View style={styles.dot} />
              <Text> Cosy</Text>
            </View>
            <View style={styles.item}>
              <View style={styles.dot} />
              <Text> Casual</Text>
            </View>
            <View style={styles.item}>
              <View style={styles.dot} />
              <Text> Chinease</Text>
            </View>
          </View>
        </View>
        <View style={styles.list}>
          <Ionicons name="ios-time" size={22} color={Colors.darkGray} style={{width:20}} />
          <View style={styles.items}>
            <View style={styles.item}>
              <View style={styles.dot} />
              <Text> Mexican</Text>
            </View>
            <View style={styles.item}>
              <View style={styles.dot} />
              <Text> English</Text>
            </View>
            <View style={styles.item}>
              <View style={styles.dot} />
              <Text> Chinease</Text>
            </View>
            <View style={styles.item}>
              <View style={styles.dot} />
              <Text> Chinease</Text>
            </View>
            <View style={styles.item}>
              <View style={styles.dot} />
              <Text> Chinease</Text>
            </View>
            <View style={styles.item}>
              <View style={styles.dot} />
              <Text> Chinease</Text>
            </View>
          </View>
        </View>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  box: {
    paddingLeft: 10,
    paddingRight:10,
    paddingTop:15,
    paddingBottom:15
  },
  list_item: {
    marginTop: 15
  },
  header: {
    color: Colors.darkGray,
    fontSize: 17
  },
  list: {
    flexDirection: "row",
    marginTop: 2,
    marginBottom: 2
  },
  items: {
    flexDirection: "row",
    marginLeft: 15,
    flexWrap: "wrap"
  },
  item: {
    flexDirection: "row",
  },
  dot: {
    width: 8,
    height: 8,
    borderRadius: 8 / 2,
    backgroundColor: Colors.darkGray,
    marginTop: 5,
    margin: 3
  }
});
export default Highlights;
