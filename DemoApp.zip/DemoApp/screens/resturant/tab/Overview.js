import React, { Component } from "react";
import { View, StyleSheet } from "react-native";
import Actions from "./Actions";
import Helights from "./Highlights";
import Gallery from "./Gallery";
import Amenities from "./Amenities";
import MoreInfo from "./MoreInfo";

class Overview extends Component {
  render() {
    return (
      <View style={styles.box}>
        <Actions />
        <Helights />
        <Gallery />
        <Amenities />
        <MoreInfo />
      </View>
    );
  }
}

const styles = StyleSheet.create({
  box: {
    backgroundColor: "#FFF"
  }
});
export default Overview;
