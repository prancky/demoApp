import React from "react";
import { View, Text, StyleSheet } from "react-native";
import Colors from "./../../../constants/Colors";
import { Ionicons } from "@expo/vector-icons";

const MoreInfo = () => {
  return (
    <View style={styles.box}>
      <Text style={styles.header}>More Info</Text>
      <View style={styles.items}>
        <View style={styles.item}>
          <Ionicons
            name="ios-mail"
            size={22}
            color={Colors.darkGray}
            style={{ width: 20 }}
          />
          <Text style={styles.link}>kingcoconut@gmail.com  </Text>
        </View>
        <View style={styles.item}>
          <Ionicons
            name="ios-globe"
            size={22}
            color={Colors.darkGray}
            style={{ width: 20 }}
          />
          <Text style={styles.link}>www.kingcoconut.com </Text>
        </View>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  box: {
    paddingLeft: 10,
    paddingRight: 10,
    paddingTop: 15,
    paddingBottom: 15
  },
  header: {
    color: Colors.darkGray,
    fontSize: 17
  },
  items:{
    marginTop: 15,
    marginBottom : 15
  },
  item: {
    flexDirection: "row"
  },
  link: {
    color: Colors.blue,
    marginLeft: 10
  }
});
export default MoreInfo;
