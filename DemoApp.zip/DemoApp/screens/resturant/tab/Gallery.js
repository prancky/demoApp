import React, { Component } from "react";
import {
  View,
  StyleSheet,
  Text,
  Dimensions,
  TouchableOpacity,
  Image
} from "react-native";
var { width } = Dimensions.get("window");
import food1 from "./../../../assets/images/foods-from-chain-restaurants-that-are-horrifyingl-1-2353-1394051081-16_big.jpg";
import food2 from './../../../assets/images/1.jpg';
import food3 from './../../../assets/images/2.jpg';

class Gallery extends Component {
  render() {
    return (
      <View style={styles.box}>
        <View style={styles.left}>
          <View>
            <TouchableOpacity>
              <Image source={food3} style={styles.image_two} />
            </TouchableOpacity>
          </View>
          <View>
            <TouchableOpacity>
              <Image source={food2} style={styles.image_three} />
            </TouchableOpacity>
          </View>
        </View>
        <View style={styles.right}>
          <TouchableOpacity>
            <Image source={food1} style={styles.image_one} />
          </TouchableOpacity>
        </View>
      </View>
    );
  }
}
const styles = StyleSheet.create({
  box: {
    padding: 5,
    flex: 1,
    flexDirection: "row"
  },
  left: {
    // width: width * 2 / 5,
    flex: 0.4,
    margin: 5
  },
  right: {
    // width: width * 3 / 5,
    flex: 0.6,
    margin: 5
  },
  image_one: {
    flex: 1,
    width: "100%",
    height: 160,
    borderRadius: 5,
    marginTop: 5,
    marginBottom: 5,
  },
  image_two: {
    flex: 1,
    width: "100%",
    height: 50,
    borderRadius: 5,
    marginTop: 5,
    marginBottom: 5
  },
  image_three: {
    flex: 1,
    width: "100%",
    height: 100,
    borderRadius: 5,
    marginTop: 5,
    marginBottom: 5
  }
});

export default Gallery;
