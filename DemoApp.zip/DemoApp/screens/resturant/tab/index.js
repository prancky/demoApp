import * as React from "react";
import { View, StyleSheet, Dimensions, Text } from "react-native";
import { TabViewAnimated, TabBar, SceneMap } from "react-native-tab-view";
import Overview from "./Overview";

const initialLayout = {
  height: 0,
  width: Dimensions.get("window").width
};

const FirstRoute = () => <Overview />;
const SecondRoute = () => (
  <View style={[styles.container, { backgroundColor: "#673ab7" }]}>
    <Text>
      {'This is a JavaScript-only implementation of swipeable tab views. Its super customizable, allowing you to do things like coverflow.'}
    </Text>
  </View>
);
const ThirdRoute = () => (
  <View style={[styles.container, { backgroundColor: "#673ab7" }]}>
    <Text>
      {'This is a JavaScript-only implementation of swipeable tab views. Its super customizable, allowing you to do things like coverflow.'}
    </Text>
  </View>
);

export default class Tabs extends React.Component {
  state = {
    index: 0,
    routes: [
      { key: "first", title: "Overview" },
      { key: "second", title: "Menu" },
      { key: "third", title: "Reviews" }
    ]
  };

  _handleIndexChange = index => this.setState({ index });

  _renderHeader = props => (
    <TabBar
      {...props}
      style={{ backgroundColor: "#F3F3F3", paddingTop: 6, paddingBottom: 6 }}
      labelStyle={{ color: "#5A6978" }}
      indicatorStyle={{ backgroundColor: "#5A6978" }}
      // tabStyle={{backgroundColor :'#FFF'}}
    />
  );

  _renderScene = SceneMap({
    first: FirstRoute,
    second: SecondRoute,
    third: ThirdRoute
  });

  render() {
    return (
      <TabViewAnimated
        navigationState={this.state}
        renderScene={this._renderScene}
        renderHeader={this._renderHeader}
        onIndexChange={this._handleIndexChange}
        initialLayout={initialLayout}
      />
    );
  }
}

const styles = StyleSheet.create({
  container: {
    flex: 1
  }
});
