import React, { Component } from "react";
import {
  View,
  TouchableOpacity,
  StyleSheet,
  Dimensions,
  Text
} from "react-native";
import { Ionicons } from "@expo/vector-icons";
import Colors from "./../../../constants/Colors";
var { width } = Dimensions.get("window");

class Actions extends Component {
  render() {
    return (
      <View style={styles.actions}>
        <TouchableOpacity style={styles.action} activeOpacity={0.6}>
          <Ionicons name="md-call" size={32} color={Colors.darkGray} />
          <Text style={styles.text_style}>Call</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.action} activeOpacity={0.6}>
          <Ionicons name="ios-send" size={34} color={Colors.darkGray} />
          <Text style={styles.text_style}>Directions</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.action} activeOpacity={0.6}>
          <Ionicons name="md-bookmark" size={30} color={Colors.darkGray} />
          <Text style={styles.text_style}>Save</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.action} activeOpacity={0.6}>
          <Ionicons name="ios-camera" size={32} color={Colors.darkGray} />
          <Text style={styles.text_style}>Add Photo</Text>
        </TouchableOpacity>
      </View>
    );
  }
}

const styles = StyleSheet.create({
  actions: {
    flex: 1,
    width: width,
    flexDirection: "row",
    height: 80,
    borderBottomWidth: 1,
    borderColor: "#CCC"
  },
  action: {
    flex: 1,
    width: width / 4,
    justifyContent: "center",
    alignItems: "center"
  },
  text_style: {
    color: "#3C344B",
    fontSize: 14
  }
});
export default Actions;
