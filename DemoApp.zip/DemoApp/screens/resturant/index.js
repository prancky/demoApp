import React, { Component } from "react";
import { ScrollView,View } from "react-native";
import Header from "./Header";
import Tabs from "./tab";

class Resturant extends Component {
  render() {
    return (
        <ScrollView>
          <Header />
          <Tabs />
        </ScrollView> 
    );
  }
}

export default Resturant;
