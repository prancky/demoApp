import React, { Component } from "react";
import { View, Text, StyleSheet } from "react-native";
import { MainBanner } from "./../../components/common";
import Colors from "./../../constants/Colors";
import { Ionicons } from "@expo/vector-icons";
import { TabViewAnimated, TabBar, SceneMap } from "react-native-tab-view";

class Header extends Component {

  getRatingStar = () => {
    let active = (
      <Ionicons
        name="ios-star"
        size={14}
        style={{ width: 14 }}
        color={Colors.yellow}
      />
    );

    let disable = (
      <Ionicons
        name="ios-star"
        size={15}
        style={{ width: 14 }}
        color={Colors.gray}
      />
    );

    return (
      <View style={[styles.rating_stare, styles.flex_row]}>
        {active}
        {active}
        {active}
        {active}
        {disable}
        <Text style={styles.count}>(442)</Text>
      </View>
    );
  }

  render() {
    return (
      <MainBanner height={220}>
        <View style={styles.content}>
          <View style={styles.left}>
            <Text style={styles.name}>Incasa Coffee</Text>
            <View>
              <View style={[styles.flex_row, styles.height_one]}>
                <Ionicons
                  name="ios-cafe"
                  size={22}
                  style={styles.icon}
                  color={Colors.noticeText}
                />
                <View>
                  <Text style={styles.sub_one}>Coffee Shop</Text>
                </View>
              </View>
              <View style={[styles.flex_row, styles.height_one]}>
                <Ionicons
                  name="ios-pin"
                  size={24}
                  style={styles.icon}
                  color={Colors.noticeText}
                />
                <View>
                  <Text style={styles.sub_two}>Main Street, Negambo</Text>
                </View>
              </View>
              <View>
                <View style={[styles.flex_row, styles.height_one]}>
                  <Ionicons
                    name="md-time"
                    size={22}
                    style={styles.icon}
                    color={Colors.noticeText}
                  />
                  <View>
                    <Text style={styles.sub_two}>{'07.00 am - 10.00 pm'}</Text>
                  </View>
                  <View style={styles.status_active}>
                    <Text style={styles.sub_three}>Open</Text>
                  </View>
                </View>
              </View>
            </View>
          </View>
          <View style={styles.right}>
            <Text style={styles.rate}>4.2</Text>
            {this.getRatingStar()}
          </View>
        </View>
      </MainBanner>
    );
  }
}

const styles = StyleSheet.create({
  content: {
    flex: 1,
    flexDirection: "row",
    padding: 10
  },
  flex_row: {
    flexDirection: "row"
  },
  height_one: {
    height: 28
  },
  left: {
    flex: 1,
    position: "absolute",
    bottom: 15,
    left: 0,
    paddingLeft: 20
  },
  right: {
    flex: 1,
    position: "absolute",
    bottom: 80,
    right: 0,
    paddingRight: 20
  },
  name: {
    color: Colors.noticeText,
    fontSize: 25,
    fontWeight: "700",
    top: -20,
  },
  sub_one: {
    color: Colors.noticeText,
    fontSize: 18,
    fontWeight: "700",
    // marginLeft: 10,
    marginTop: -5
  },
  icon: {
    width: 40,
    top: -5
  },
  sub_two: {
    color: Colors.noticeText,
    fontSize: 13,
    fontWeight: "700"
  },
  sub_three: {
    color: Colors.noticeText,
    fontSize: 13,
    fontWeight: "700",
    lineHeight: 0
  },
  status_active: {
    backgroundColor: Colors.green,
    padding: 5,
    borderRadius: 3,
    top: -4,
    left: 5
  },
  rate: {
    fontSize: 40,
    color: Colors.noticeText,
    fontWeight: "700",
    textAlign: "right"
  },
  count: {
    color: Colors.noticeText,
    fontSize: 12
  }
});
export default Header;
